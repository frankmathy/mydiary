public interface S01_Executable {

    static void main(String... args) {
        System.out.println("hello,duke");
    }
}
