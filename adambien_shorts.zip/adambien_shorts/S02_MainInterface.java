interface S02_MainInterface {

    static void main(String... args) {
        System.out.println("hello,duke");
    }
}
