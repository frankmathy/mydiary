
@FunctionalInterface
interface S24_FunctionalInterface {
    void first();
}