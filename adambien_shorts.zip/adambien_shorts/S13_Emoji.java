public class S13_Emoji {
    static final String ROCKET = "🚀";

    public static void main(String[] args) {
        System.out.println(ROCKET);
    }
}