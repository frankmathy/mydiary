interface S50_CrazyQuestion {

  static void main(String... args) {
    
     int first[][];
     int []second[];
     int [][]third;
     int[] []fourth;
     int[][] fifth;
     int[] []seventh;
     int[] eight[];

  }
}