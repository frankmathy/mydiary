interface S44_Ternary {

  static void main(String... args) {
    var input = "";
    var developer = input.isBlank()?"duke":input;
    System.out.println(developer);
  }
}