public class S00_BoringMain {

    public static void main(String[] args) {
        System.out.println("boring and complex");
    }
}