# Thanks for attending!

This is a collection of daily shorts from: http://youtube.com/bienadam/shorts
You may also like my podcast / workshops. You will find all links here: https://airhacks.industries

You can run the indivisual shorts without compiling e.g.: 

`java S12_CustomJVM.java`
