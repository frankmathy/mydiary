void main() {
  System.out.println("hello, world");
}