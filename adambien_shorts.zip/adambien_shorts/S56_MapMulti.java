import java.util.function.Consumer;
import java.util.stream.Stream;

interface S56_MapMulti {

  static void expand(String css, 
  Consumer<String> sink){
    for(var e:css.split(","))
      sink.accept(e);
  }

  static void main(String... args) {
    var css = Stream.of("hello,world",
        "duke,java");
    var expanded = css.mapMulti(S56_MapMulti::expand)
    .toList();
    System.out.println(expanded);
  }
}