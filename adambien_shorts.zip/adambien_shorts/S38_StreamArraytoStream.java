import java.util.stream.Stream;

public class S38_StreamArraytoStream {

    public static void main(String[] args) {
        var count = Stream.of(args).map(String::toUpperCase).count();
        System.out.println(count);
    }
}