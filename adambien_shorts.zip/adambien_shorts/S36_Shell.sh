#!/usr/bin/java --source 17
public class App {
    public static void main(String[] args) {
        System.out.println("hello,duke");
    }
}