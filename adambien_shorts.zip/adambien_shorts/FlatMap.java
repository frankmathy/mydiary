import java.util.Optional;

public class FlatMap {

  static Optional<String> first() {
    return Optional.of("nic");
  }

  static Optional<String> second(String hello) {
    System.out.println(hello);
    return Optional.of("nice " + hello);
  }

  public static void main(String[] args) {
    first().flatMap(FlatMap::second);

  }
}
